package com.example.projecttwojasonditullio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // setting up variables for buttons and editText
    EditText username,password;
    Button btnSignUp,btnSignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // linking variables for buttons and editTexts to their respective objects on the login page
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        btnSignIn = (Button) findViewById(R.id.logIn);
        btnSignUp = (Button) findViewById(R.id.createAccount);

        // creating new instance of FitnessDatabase
        FitnessDatabase db = new FitnessDatabase(this);

        // creating functionality for sign in button
        btnSignIn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                // getting username and password entered by user
                String user = username.getText().toString();
                String pass = password.getText().toString();

                // if either the username or password fields are empty, notify user to fill in fields
                if(user.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, "Fill in all the text fields.", Toast.LENGTH_SHORT).show();
                }
                // if all fields have data, check username and password against table
                else{
                    Boolean userCheck = db.checkUserPass(user,pass);
                    // if user does exist then take them to homepage
                    if(userCheck == true){
                        Intent intent = new Intent(getApplicationContext(),HomePage.class);
                        startActivity(intent);
                    }
                    // if user does not exist then notify them that the account doesn't exist
                    else{
                        Toast.makeText(MainActivity.this, "This account doesn't exist!.", Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });

        // adding functionality to sign up button for users
        btnSignUp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // getting username and password entered by user
                String user = username.getText().toString();
                String pass = password.getText().toString();

                // if either the username or password fields are empty, notify user to fill in fields
                if(user.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, "Fill in all the text fields.", Toast.LENGTH_SHORT).show();
                }
                // else, check if the username that the user entered is already tied to an account
                else{
                    Boolean userCheck = db.checkUsername(user);
                    // if username is not already in use, add new account to login table and take user to goal page to set weight goal
                    if(userCheck == false){
                        db.insert(user,pass);
                        Intent intent = new Intent(getApplicationContext(),Goal.class);
                        startActivity(intent);
                    }
                    // else if username is already in use, tell the user to log in with the username
                    else{
                        Toast.makeText(MainActivity.this, "This user already exists! Please log in.", Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });

    }

}

