package com.example.projecttwojasonditullio;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class Setting extends AppCompatActivity {
    // creating button variable for user to enable SMS permissions
    Button sms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        // linking sms button variable to button on settings page
        sms = (Button) findViewById(R.id.sms);

        // adding functionality to button
        sms.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // when the button is clicked and SMS permissions are not enabled, prompt user to allow or deny app access to SEND_SMS
                ActivityCompat.requestPermissions(Setting.this, new String[]{Manifest.permission.SEND_SMS}, PackageManager.PERMISSION_GRANTED);
            }

        });
    }
}


