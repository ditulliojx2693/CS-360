package com.example.projecttwojasonditullio;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class HomePage extends  AppCompatActivity{

    // creating buttons and FitnessDatabase
    FloatingActionButton btnSettings,btnDaily,btnGoal;
    static FitnessDatabase fitnessDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);

        //creating new instance of FitnessDatabase
        fitnessDatabase = new FitnessDatabase(this);

        //setting up List of daily weights entered
        ListView lvContent = findViewById(R.id.lvContent);

        //populateList method called to read all daily weights currently stored in table
        final SimpleCursorAdapter simpleCursorAdapter = fitnessDatabase.populateList();
        lvContent.setAdapter(simpleCursorAdapter);
        lvContent.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            //setting up edit page for when weight items are tapped
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Cursor cursor = (Cursor) simpleCursorAdapter.getItem(i);
                String weight = cursor.getString(1);
                String date = cursor.getString(2);

                // moving to page for editing daily weights
                Intent intent = new Intent(HomePage.this, EditWeightActivity.class);

                // sending tapped daily weight data to editing page
                intent.putExtra("l", l);
                intent.putExtra("weight", weight);
                intent.putExtra("date", date);
                startActivity(intent);
                finish();
                Toast.makeText(HomePage.this, weight, Toast.LENGTH_LONG).show();
            }
        });

        // setting up each button on home page
        btnSettings = (FloatingActionButton) findViewById(R.id.settings);
        btnDaily = (FloatingActionButton) findViewById(R.id.dailyWeight);
        btnGoal = (FloatingActionButton) findViewById(R.id.goalWeight);

        // button to take user to settings
        btnSettings.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), Setting.class);
                startActivity(intent);
            }

        });

        // button to take user to daily weight input page
        btnDaily.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(),DailyWeight.class);
                startActivity(intent);
            }

        });

        // button to take user to goal weight input page
        btnGoal.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(),Goal.class);
                startActivity(intent);
            }

        });
    }
}
