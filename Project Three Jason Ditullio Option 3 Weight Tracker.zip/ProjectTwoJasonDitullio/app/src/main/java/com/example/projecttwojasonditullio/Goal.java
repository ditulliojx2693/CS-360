package com.example.projecttwojasonditullio;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Goal extends AppCompatActivity {

    // setting up button and edittext variables
    Button btnSetGoal;
    EditText goal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_goal);

        // creating instance of FitnessDatabase
        FitnessDatabase db = new FitnessDatabase(this);

        // setting button ad edittext values from goal page to their respective variables
        btnSetGoal = (Button) findViewById(R.id.submitGoal);
        goal = (EditText) findViewById(R.id.weightGoal);

        // giving functionality to set goal button
        btnSetGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double g;
                // if user does not input goal weight, set g to 0.0
                if(goal.getText().toString().equals("")){
                    g = 0.0;
                }
                // else set g equal to the double that the user entered
                else{
                    g = Double.valueOf(goal.getText().toString());
                }

                // if user didn't input goal weight, notify them to enter in value first
                if(g == 0.0){
                    Toast.makeText(Goal.this, "Fill in the goal weight field.", Toast.LENGTH_SHORT).show();
                }
                // else insert g into the goal weight table and return user to home page
                else{
                    db.insert(g);
                    Intent intent = new Intent(getApplicationContext(),HomePage.class);
                    startActivity(intent);
                }
            }
        });
    }
}
