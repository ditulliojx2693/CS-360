package com.example.projecttwojasonditullio;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DailyWeight extends AppCompatActivity {

    // setting up Button and EditText variables
    Button btnSetWeight;

    EditText weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_weight);

        // creating a new instance of FitnessDatabase
        FitnessDatabase db = new FitnessDatabase(this);

        // assigning buttons from page to the variables
        btnSetWeight = (Button) findViewById(R.id.submitDaily);
        weight = (EditText) findViewById(R.id.weight);

        // adding functionality to set weight button
        btnSetWeight.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                // checking to make sure that user entered a value for weight
                Double w;
                if (weight.getText().toString().equals("")){
                    w = 0.0;
                }
                else{
                    w = Double.valueOf(weight.getText().toString());
                }
                // creating a variable to track current date for table
                String date = new SimpleDateFormat("MM-dd-yyyy").format(new Date());

                // if the user did not input a weight, this notifies them to enter one
                if(w == 0.0){
                    Toast.makeText(DailyWeight.this, "Please enter your daily weight", Toast.LENGTH_LONG).show();
                }
                // if the user did input a weight then the method checks if the user has enabled SMS permissions
                else{
                    if (ContextCompat.checkSelfPermission(DailyWeight.this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED){

                        // getting most recent goal weight from goal table
                        Cursor cursor = db.getReadableDatabase().rawQuery("SELECT goal FROM goal",null);
                        cursor.moveToLast();
                        // turning goal weight from cursor into a double for comparison
                        Double g = cursor.getDouble(0);
                        // if daily weight matches goal weight then method sends a message to user's phone number
                        if (Double.compare(w,g) == 0){
                            sendMessage();
                        }
                    }
                    // adding daily weight to daily weight table regardless if user had sms permissions enabled or not
                    db.insert(w,date);

                    // moving user back to main home page.
                    Intent intent = new Intent(getApplicationContext(),HomePage.class);
                    startActivity(intent);
                }
            }

        });
    }

    private void sendMessage() {
        // creating default variables for emulator phone number and message to be sent
        String phone = "+1-555-521-5554";
        String message = "You reached your goal weight today!";

        // trimming strings down so they can be used properly by SmsManager
        String sPhone = phone.toString().trim();
        String sMessage = message.toString().trim();

        // if strings aren't empty, make SmsManager send message to user
        if(!sPhone.equals("") && !sMessage.equals("")){
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(sPhone, null, sMessage,
                    null,null);
            // notify user that sms sent successfully
            Toast.makeText(DailyWeight.this, "SMS sent successfully!", Toast.LENGTH_LONG).show();
        }
    }
}
