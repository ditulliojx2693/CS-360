package com.example.projecttwojasonditullio;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class EditWeightActivity extends AppCompatActivity {

    // setting up variables to receive weight data to edit
    TextView tvDate;
    EditText etWeight;
    long id;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weight);

        // setting weight variables equal to their original data
        id = getIntent().getExtras().getLong("l");
        String weight = getIntent().getExtras().getString("weight");
        String date = getIntent().getExtras().getString("date");

        // setting display variables on edit weight page to match data
        tvDate = findViewById(R.id.tvDate);
        etWeight = findViewById(R.id.etWeight);
        tvDate.setText(date);
        etWeight.setText(weight);
    }

    // method to allow users to edit the current weight entry they are on
    public void editWeight(View view){
        String weight = etWeight.getText().toString();
        HomePage.fitnessDatabase.updateWeightNew(id, weight);
        startActivity(new Intent(EditWeightActivity.this, HomePage.class));
        finish();
    }

    // method to allow users to delete the current weight entry they are on
    public void deleteWeight(View view){
        HomePage.fitnessDatabase.deleteDataNew(id);
        startActivity(new Intent(EditWeightActivity.this, HomePage.class));
        finish();
    }
}
