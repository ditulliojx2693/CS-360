package com.example.projecttwojasonditullio;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.SimpleCursorAdapter;

public class FitnessDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "fitness.db";
    private static final int VERSION = 1;

    Context context;

   //constructor for FitnessDatabase
    public FitnessDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;

    }

    @Override
    // setting up three required tables
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table login(id Integer primary key autoincrement, username Text, password Text)");
        db.execSQL("create table weights(_id Integer primary key autoincrement, weight Real, date Text)");
        db.execSQL("create table goal(id Integer primary key autoincrement, goal Real)");
    }

    @Override
    // changing version number if upgraded
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists login");
        db.execSQL("drop table if exists weights");
        db.execSQL("drop table if exists goal");
        onCreate(db);
    }

    // insert for Login table
    public boolean insert(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = db.insert("login",null,contentValues);

        if (result==-1){
            return false;
        }
        else{
            return true;
        }
    }

    // insert for daily weight table
    public boolean insert(double weight, String date){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("weight", weight);
        contentValues.put("date", date);
        long result = db.insert("weights",null,contentValues);

        if (result==-1){
            return false;
        }
        else{
            return true;
        }
    }

    // insert for goal weight table
    public boolean insert(double goal){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("goal", goal);
        long result = db.insert("goal",null,contentValues);

        if (result==-1){
            return false;
        }
        else{
            return true;
        }
    }

    // method to check if username is already in login table
    public boolean checkUsername(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from login where username = ?", new String [] {username});
        if(cursor.getCount()>0){
            return true;
        }
        else{
            return false;
        }
    }

    // method to check if username and password combo are in login table
    public boolean checkUserPass(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from login where username = ? and password = ?", new String [] {username,password});
        if(cursor.getCount()>0){
            return true;
        }
        else{
            return false;
        }
    }

    // method that populates the home page with the current Daily weights that have been entered into the table
    public SimpleCursorAdapter populateList(){
        SQLiteDatabase db = this.getWritableDatabase();
        String columns[] = {"_id","weight","date"};
        Cursor cursor = db.query("weights", columns, null, null, null, null,null);
        String[] fromFieldWeights = new String[]{
                "_id","weight","date"
        };
        int[] toViewIDs = new int[]{R.id.item_id, R.id.item_weight, R.id.item_date};
        SimpleCursorAdapter contactAdapter = new SimpleCursorAdapter(
                context,
                R.layout.single_item,
                cursor,
                fromFieldWeights,
                toViewIDs
        );
        return contactAdapter;
    }

    // method to let user update daily weight value on home page
    public int updateWeightNew(long id, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("weight", weight);
        String whereArgs[] = {""+id};
        int count = db.update("weights",contentValues, "_id"+"=?",whereArgs);
        return count;
    }

    // method to let user delete daily weight value from home page
    public int deleteDataNew(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereArgs[] = {""+id};
        int count = db.delete("weights", "_id"+"=?",whereArgs);
        return count;
    }
}
